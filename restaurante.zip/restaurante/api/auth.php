<?php
// api/auth.php
// (Opcional) endpoints para login/register via AJAX.
// Este proyecto usa las páginas /public/login.php y /public/register.php.
// Puedes implementar endpoints JSON aquí si los necesitas.
echo json_encode(['status' => 'not_implemented']);
