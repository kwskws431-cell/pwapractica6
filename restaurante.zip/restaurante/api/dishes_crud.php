<?php
// api/dishes_crud.php
require_once __DIR__ . '/../includes/auth_helpers.php';
require_login();
if (!check_role('Administrator')) {
    die('No autorizado');
}
require_once __DIR__ . '/../includes/db.php';

$action = $_POST['action'] ?? null;

if ($action === 'create') {
    $name = trim($_POST['name']);
    $desc = trim($_POST['description']);
    $price = floatval($_POST['price']);
    $stmt = $pdo->prepare("INSERT INTO dishes (name, description, price) VALUES (?, ?, ?)");
    $stmt->execute([$name, $desc, $price]);
    header('Location: /restaurante/public/dishes.php');
    exit;
}

if ($action === 'delete') {
    $id = intval($_POST['id']);
    $stmt = $pdo->prepare("DELETE FROM dishes WHERE id = ?");
    $stmt->execute([$id]);
    header('Location: /restaurante/public/dishes.php');
    exit;
}

// Puedes agregar update si lo deseas (se deja como ejercicio opcional)
header('Location: /restaurante/public/dishes.php');
exit;
