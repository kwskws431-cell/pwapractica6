<?php
// api/place_order.php
require_once __DIR__ . '/../includes/auth_helpers.php';
require_login();
require_once __DIR__ . '/../includes/db.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'invalid_method']);
    exit;
}

$dish_id = intval($_POST['dish_id'] ?? 0);
$quantity = max(1, intval($_POST['quantity'] ?? 1));
$user = current_user();

$stmt = $pdo->prepare("INSERT INTO orders (user_id, dish_id, quantity) VALUES (?, ?, ?)");
$stmt->execute([$user['id'], $dish_id, $quantity]);

echo json_encode(['success' => true, 'order_id' => $pdo->lastInsertId()]);
exit;
