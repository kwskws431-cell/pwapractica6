<?php
// api/update_order_status.php
require_once __DIR__ . '/../includes/auth_helpers.php';
require_login();
require_once __DIR__ . '/../includes/db.php';
header('Content-Type: application/json');

if (!check_role(['Chef','Waiter','Administrator'])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'no_permission']);
    exit;
}

$order_id = intval($_POST['order_id'] ?? 0);
$status = $_POST['status'] ?? '';
$allowed = ['Pending','Preparing','Ready to serve','Served'];
if (!in_array($status, $allowed)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'invalid_status']);
    exit;
}
$stmt = $pdo->prepare("UPDATE orders SET status = ? WHERE id = ?");
$stmt->execute([$status, $order_id]);
echo json_encode(['success' => true]);
exit;
