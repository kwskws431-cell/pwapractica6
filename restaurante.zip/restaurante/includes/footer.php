</main>
<footer class="text-center py-3">
  <small>&copy; <?=date('Y')?> Restaurante</small>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="/restaurante/public/assets/js/main.js"></script>
</body>
</html>
