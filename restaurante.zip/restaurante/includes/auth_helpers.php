<?php
// includes/auth_helpers.php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/db.php';

function require_login() {
    if (!isset($_SESSION['user'])) {
        header('Location: /restaurante/public/login.php');
        exit;
    }
}

function login_user_by_id($user_id) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT u.id, u.username, u.email, u.role_id, r.name AS role_name FROM users u JOIN roles r ON u.role_id = r.id WHERE u.id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();
    if ($user) {
        $_SESSION['user'] = $user;
        return true;
    }
    return false;
}

function current_user() {
    return $_SESSION['user'] ?? null;
}

function check_role($roles) {
    $user = current_user();
    if (!$user) return false;
    if (is_string($roles)) $roles = [$roles];
    return in_array($user['role_name'], $roles);
}
