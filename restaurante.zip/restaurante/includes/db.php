<?php
// Configuración de la base de datos para PDO

$DB_HOST = '127.0.0.1';  // Dirección del servidor de base de datos (localhost)
$DB_NAME = 'restaurante'; // Nombre de la base de datos
$DB_USER = 'root';        // Usuario de la base de datos (por defecto en XAMPP/Laragon/WAMP)
$DB_PASS = '';            // Contraseña de la base de datos (por defecto está vacía en XAMPP/Laragon/WAMP)

try {
    // Creación de la conexión PDO
    $pdo = new PDO("mysql:host={$DB_HOST};dbname={$DB_NAME};charset=utf8mb4", $DB_USER, $DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, // Mostrar errores en caso de que haya
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC // Fetch como un arreglo asociativo
    ]);
} catch (Exception $e) {
    // Si ocurre un error al conectar con la base de datos, muestra el error
    die("❌ Error de conexión: " . $e->getMessage());
}
?>
