// public/assets/js/main.js
document.addEventListener('DOMContentLoaded', function () {

  // Enviar pedido con AJAX
  const orderForm = document.getElementById('orderForm');
  if (orderForm) {
    orderForm.addEventListener('submit', async function (e) {
      e.preventDefault();
      const fd = new FormData(orderForm);
      const resp = await fetch('/restaurante/api/place_order.php', {
        method: 'POST',
        body: fd
      });
      const json = await resp.json();
      const resEl = document.getElementById('orderResult');
      if (json.success) {
        if (resEl) resEl.innerHTML = '<div class="alert alert-success">Pedido realizado (ID: ' + json.order_id + ')</div>';
        orderForm.reset();
      } else {
        if (resEl) resEl.innerHTML = '<div class="alert alert-danger">Error al realizar pedido</div>';
      }
    });
  }

  // Cambiar estado desde chef_orders (AJAX)
  document.querySelectorAll('.status-change').forEach(function (sel) {
    sel.addEventListener('change', async function () {
      const id = sel.dataset.id;
      const status = sel.value;
      const fd = new FormData();
      fd.append('order_id', id);
      fd.append('status', status);
      const resp = await fetch('/restaurante/api/update_order_status.php', {
        method: 'POST',
        body: fd
      });
      const j = await resp.json();
      if (j.success) {
        const el = document.getElementById('status-' + id);
        if (el) el.textContent = status;
      } else {
        alert('Error al actualizar estado');
      }
    });
  });

});
