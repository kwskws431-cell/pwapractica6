<?php
// public/dishes.php
require_once __DIR__ . '/../includes/auth_helpers.php';
require_login();
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/header.php';

// Solo admin puede crear/editar/eliminar (lista visible para todos logueados)
$stmt = $pdo->query("SELECT * FROM dishes ORDER BY name");
$dishes = $stmt->fetchAll();
?>
<h2>Platos</h2>
<?php if (check_role('Administrator')): ?>
  <button class="btn btn-success mb-3" data-bs-toggle="modal" data-bs-target="#addDishModal">Agregar plato</button>
<?php endif; ?>

<table class="table table-striped">
  <thead><tr><th>Nombre</th><th>Descripción</th><th>Precio</th><th>Acciones</th></tr></thead>
  <tbody>
    <?php foreach ($dishes as $d): ?>
    <tr>
      <td><?=htmlspecialchars($d['name'])?></td>
      <td><?=htmlspecialchars($d['description'])?></td>
      <td>$<?=number_format($d['price'],2)?></td>
      <td>
        <?php if (check_role('Administrator')): ?>
          <form style="display:inline" method="post" action="/restaurante/api/dishes_crud.php">
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="id" value="<?=$d['id']?>">
            <button class="btn btn-sm btn-danger" onclick="return confirm('Eliminar plato?')">Eliminar</button>
          </form>
        <?php endif; ?>
      </td>
    </tr>
    <?php endforeach; ?>
  </tbody>
</table>

<!-- Modal: Create dish -->
<?php if (check_role('Administrator')): ?>
<div class="modal fade" id="addDishModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form method="post" action="/restaurante/api/dishes_crud.php">
        <div class="modal-header"><h5 class="modal-title">Agregar plato</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
        <div class="modal-body">
          <input type="hidden" name="action" value="create">
          <input class="form-control mb-2" name="name" placeholder="Nombre" required>
          <textarea class="form-control mb-2" name="description" placeholder="Descripción"></textarea>
          <input class="form-control mb-2" name="price" type="number" step="0.01" placeholder="Precio" required>
        </div>
        <div class="modal-footer"><button class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button><button class="btn btn-primary">Guardar</button></div>
      </form>
    </div>
  </div>
</div>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
