<?php
// public/index.php - landing / menú público
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/header.php';

$stmt = $pdo->query("SELECT * FROM dishes ORDER BY name");
$dishes = $stmt->fetchAll();
?>
<div class="row">
  <div class="col-md-8">
    <h1 class="mb-3">Menú del Restaurante</h1>
    <div class="row">
      <?php foreach ($dishes as $d): ?>
        <div class="col-md-6 mb-3">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title"><?=htmlspecialchars($d['name'])?> <small class="text-muted">$<?=number_format($d['price'],2)?></small></h5>
              <p class="card-text"><?=htmlspecialchars($d['description'])?></p>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>

  <div class="col-md-4">
    <h4>Acceso</h4>
    <p><a class="btn btn-primary" href="/restaurante/public/login.php">Iniciar sesión</a></p>
    <p><a class="btn btn-outline-secondary" href="/restaurante/public/register.php">Registrarse</a></p>
  </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
