<?php
// public/chef_orders.php
require_once __DIR__ . '/../includes/auth_helpers.php';
require_login();
if (!check_role('Chef')) {
    header('Location: /restaurante/public/dashboard.php'); exit;
}
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/header.php';

$stmt = $pdo->query("SELECT o.*, u.username, d.name AS dish_name FROM orders o JOIN users u ON o.user_id = u.id JOIN dishes d ON o.dish_id = d.id ORDER BY o.created_at DESC");
$orders = $stmt->fetchAll();
?>
<h2>Pedidos (Chef)</h2>
<table class="table">
  <thead><tr><th>ID</th><th>Cliente</th><th>Plato</th><th>Cant</th><th>Status</th><th>Acciones</th></tr></thead>
  <tbody>
    <?php foreach ($orders as $o): ?>
    <tr>
      <td><?=$o['id']?></td>
      <td><?=htmlspecialchars($o['username'])?></td>
      <td><?=htmlspecialchars($o['dish_name'])?></td>
      <td><?=$o['quantity']?></td>
      <td id="status-<?=$o['id']?>"><?=htmlspecialchars($o['status'])?></td>
      <td>
        <select class="form-select form-select-sm status-change" data-id="<?=$o['id']?>">
          <option value="Pending" <?= $o['status']==='Pending' ? 'selected' : '' ?>>Pending</option>
          <option value="Preparing" <?= $o['status']==='Preparing' ? 'selected' : '' ?>>Preparing</option>
          <option value="Ready to serve" <?= $o['status']==='Ready to serve' ? 'selected' : '' ?>>Ready to serve</option>
          <option value="Served" <?= $o['status']==='Served' ? 'selected' : '' ?>>Served</option>
        </select>
      </td>
    </tr>
    <?php endforeach; ?>
  </tbody>
</table>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
