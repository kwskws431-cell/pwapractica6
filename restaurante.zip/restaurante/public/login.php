<?php
// public/login.php
require_once __DIR__ . '/../includes/db.php'; // Aquí está la conexión PDO

session_start();
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');  // Toma el email del formulario
    $password = $_POST['password'] ?? '';  // Toma la contraseña del formulario

    // Preparamos la consulta para obtener el usuario
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    // Comprobamos si el usuario existe y si la contraseña es correcta
    if ($user && password_verify($password, $user['password'])) {
        // Si la contraseña es correcta, obtenemos el nombre del rol
        $stmt2 = $pdo->prepare("SELECT name FROM roles WHERE id = ?");
        $stmt2->execute([$user['role_id']]);
        $role_name = $stmt2->fetchColumn();

        // Guardamos los datos del usuario en la sesión
        $_SESSION['user'] = [
            'id' => $user['id'],
            'username' => $user['username'],
            'email' => $user['email'],
            'role_id' => $user['role_id'],
            'role_name' => $role_name
        ];

        // Redirigimos a dashboard.php
        header('Location: /restaurante/public/dashboard.php');
        exit;
    } else {
        // Si las credenciales no son correctas
        $error = "Credenciales inválidas.";
    }
}

require_once __DIR__ . '/../includes/header.php';
?>
<div class="row justify-content-center">
  <div class="col-md-6">
    <h2>Iniciar sesión</h2>
    <?php if ($error): ?><div class="alert alert-danger"><?=htmlspecialchars($error)?></div><?php endif; ?>
    <form method="post" class="mt-3">
      <input class="form-control mb-2" name="email" type="email" placeholder="Email" required>
      <input class="form-control mb-2" name="password" type="password" placeholder="Contraseña" required>
      <button class="btn btn-primary">Entrar</button>
    </form>
  </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
