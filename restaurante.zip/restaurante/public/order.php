<?php
// public/order.php
require_once __DIR__ . '/../includes/auth_helpers.php';
require_login();
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/header.php';

$stmt = $pdo->query("SELECT * FROM dishes ORDER BY name");
$dishes = $stmt->fetchAll();
?>
<h2>Realizar pedido</h2>

<form id="orderForm">
  <div class="mb-2">
    <label>Plato</label>
    <select name="dish_id" class="form-select" required>
      <?php foreach ($dishes as $d): ?>
        <option value="<?=$d['id']?>"><?=htmlspecialchars($d['name'])?> - $<?=number_format($d['price'],2)?></option>
      <?php endforeach; ?>
    </select>
  </div>
  <div class="mb-2">
    <label>Cantidad</label>
    <input name="quantity" type="number" min="1" value="1" class="form-control" required>
  </div>
  <button class="btn btn-success">Pedir</button>
</form>

<div id="orderResult" class="mt-3"></div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
