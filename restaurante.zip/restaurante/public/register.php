<?php
// public/register.php
require_once __DIR__ . '/../includes/db.php';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $role_id = intval($_POST['role_id'] ?? 4);

    if (!$username || !$email || !$password) {
        $error = "Complete todos los campos.";
    } else {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO users (username, email, password, role_id) VALUES (?, ?, ?, ?)");
        try {
            $stmt->execute([$username, $email, $hash, $role_id]);
            header('Location: /restaurante/public/login.php?registered=1');
            exit;
        } catch (Exception $e) {
            $error = "Error: " . $e->getMessage();
        }
    }
}

require_once __DIR__ . '/../includes/header.php';
?>
<div class="row justify-content-center">
  <div class="col-md-6">
    <h2>Registro</h2>
    <?php if ($error): ?><div class="alert alert-danger"><?=htmlspecialchars($error)?></div><?php endif; ?>
    <form method="post" class="mt-3">
      <input class="form-control mb-2" name="username" placeholder="Usuario" required>
      <input class="form-control mb-2" name="email" type="email" placeholder="Email" required>
      <input class="form-control mb-2" name="password" type="password" placeholder="Contraseña" required>
      <select class="form-select mb-2" name="role_id">
        <option value="4" selected>Client</option>
        <option value="3">Waiter</option>
        <option value="2">Chef</option>
        <option value="1">Administrator</option>
      </select>
      <button class="btn btn-success">Registrarse</button>
    </form>
  </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
