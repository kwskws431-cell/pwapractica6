<?php
// public/dashboard.php
require_once __DIR__ . '/../includes/auth_helpers.php';
require_login();
$user = current_user();
require_once __DIR__ . '/../includes/header.php';
?>
<h1>Bienvenido, <?=htmlspecialchars($user['username'])?> (<?=htmlspecialchars($user['role_name'])?>)</h1>
<div class="mt-3">
  <?php if (check_role('Administrator')): ?>
    <a href="/restaurante/public/dishes.php" class="btn btn-secondary">Gestionar platos</a>
    <a href="/restaurante/public/manage_users.php" class="btn btn-secondary">Gestionar usuarios</a>
  <?php endif; ?>

  <?php if (check_role(['Waiter','Client'])): ?>
    <a href="/restaurante/public/order.php" class="btn btn-primary">Realizar pedido</a>
  <?php endif; ?>

  <?php if (check_role('Chef')): ?>
    <a href="/restaurante/public/chef_orders.php" class="btn btn-warning">Ver pedidos (Chef)</a>
  <?php endif; ?>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
