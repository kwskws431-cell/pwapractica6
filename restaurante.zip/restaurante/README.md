# Restaurante - Sistema básico

## Requisitos
- PHP 7.4+ con PDO MySQL
- MySQL/MariaDB
- Servidor local (XAMPP, WAMP, Laragon...)

## Instalación rápida (localhost)
1. Coloca la carpeta `restaurante` dentro de tu carpeta pública (ej. `htdocs/restaurante`).
2. Importa `sql/schema.sql` en phpMyAdmin (o ejecuta el script).
3. Ajusta credenciales en `includes/db.php` si es necesario.
4. Abre en el navegador: `http://localhost/restaurante/public/index.php`
5. Regístrate y prueba roles: Administrator, Chef, Waiter, Client.

## Notas
- Se usan `password_hash()` y `password_verify()` para contraseñas.
- Endpoints AJAX: `api/place_order.php` y `api/update_order_status.php`.
- Mejora recomendada: CSRF tokens, validación en el servidor, subida de imágenes, roles dinámicos, HTTPS.
